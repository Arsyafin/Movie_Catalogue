package com.marfin.moviecatalogue;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

import static android.provider.BaseColumns._ID;
import static com.marfin.moviecatalogue.DatabaseContract.FavoriteMovieColumns.OVERVIEW;
import static com.marfin.moviecatalogue.DatabaseContract.FavoriteMovieColumns.POSTER_PATH;
import static com.marfin.moviecatalogue.DatabaseContract.FavoriteMovieColumns.TABLE_NAME;
import static com.marfin.moviecatalogue.DatabaseContract.FavoriteMovieColumns.TITLE;

public class FavoritesMovieHelper {
    private static final String DATABASE_TABLE = TABLE_NAME;
    private final DatabaseHelper databaseHelper;
    private static FavoritesMovieHelper INSTANCE;

    private SQLiteDatabase database;

    private FavoritesMovieHelper(Context context) {
        databaseHelper = new DatabaseHelper(context);
    }

    public static FavoritesMovieHelper getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (SQLiteOpenHelper.class) {
                if (INSTANCE == null) {
                    INSTANCE = new FavoritesMovieHelper(context);
                }
            }
        }
        return INSTANCE;
    }


    public void open() throws SQLException {
        database = databaseHelper.getWritableDatabase();
    }

    public void close() {
        databaseHelper.close();

        if (database.isOpen())
            database.close();
    }

    public ArrayList<FavoritesMovie> query() {
        ArrayList<FavoritesMovie> arrayList = new ArrayList<>();
        Cursor cursor = database.query(DATABASE_TABLE
                , null
                , null
                , null
                , null
                , null, _ID + " DESC"
                , null);
        cursor.moveToFirst();
        FavoritesMovie favoriteMovie;
        if (cursor.getCount() > 0) {
            do {
                favoriteMovie = new FavoritesMovie();
                favoriteMovie.setId(cursor.getInt(cursor.getColumnIndexOrThrow(_ID)));
                favoriteMovie.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(TITLE)));
                favoriteMovie.setOverview(cursor.getString(cursor.getColumnIndexOrThrow(OVERVIEW)));
                favoriteMovie.setPosterpath(cursor.getString(cursor.getColumnIndexOrThrow(POSTER_PATH)));

                arrayList.add(favoriteMovie);
                cursor.moveToNext();

            } while (!cursor.isAfterLast());
        }
        cursor.close();
        return arrayList;
    }

    public long insert(FavoritesMovie favoriteMovie) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(TITLE, favoriteMovie.getTitle());
        initialValues.put(OVERVIEW, favoriteMovie.getOverview());
        initialValues.put(POSTER_PATH, favoriteMovie.getPosterpath());
        return database.insert(DATABASE_TABLE, null, initialValues);
    }

    public int update(FavoritesMovie favoriteMovie) {
        ContentValues args = new ContentValues();
        args.put(TITLE, favoriteMovie.getTitle());
        args.put(OVERVIEW, favoriteMovie.getOverview());
        args.put(POSTER_PATH, favoriteMovie.getPosterpath());
        return database.update(DATABASE_TABLE, args, _ID + "= '" + favoriteMovie.getId() + "'", null);
    }

    public int delete(int id) {
        return database.delete(TABLE_NAME, _ID + " = '" + id + "'", null);
    }

    public Cursor queryByIdProvider(String id) {
        return database.query(DATABASE_TABLE, null
                , _ID + " = ?"
                , new String[]{id}
                , null
                , null
                , null
                , null);
    }

    public Cursor queryProvider() {
        return database.query(DATABASE_TABLE
                , null
                , null
                , null
                , null
                , null
                , _ID + " ASC");
    }

    public long insertProvider(ContentValues values) {
        return database.insert(DATABASE_TABLE, null, values);
    }

    public int updateProvider(String id, ContentValues values) {
        return database.update(DATABASE_TABLE, values, _ID + " = ?", new String[]{id});
    }

    public int deleteProvider(String id) {
        return database.delete(DATABASE_TABLE, _ID + " = ?", new String[]{id});
    }
}
