package com.marfin.moviecatalogue;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import static com.marfin.moviecatalogue.MainActivity.tvShowsFavoriteDb;

public class TvShowsFavoriteActivity extends AppCompatActivity {
    private RecyclerView rvTvShowsFav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.favorites);
        setTitle(R.string.favorite_tvshows);

        rvTvShowsFav = findViewById(R.id.rv_fav);
        rvTvShowsFav.setLayoutManager(new LinearLayoutManager(this));

        getTvShowFav();
    }

    private void getTvShowFav() {
        List<TvShowsFavorite> tvShowFavorite = tvShowsFavoriteDb.tvShowsFavoriteDao().getFavoriteData();
        TvShowsFavoriteAdapter tvShowFavAdapter = new TvShowsFavoriteAdapter(tvShowFavorite);
        rvTvShowsFav.setAdapter(tvShowFavAdapter);
    }


}
