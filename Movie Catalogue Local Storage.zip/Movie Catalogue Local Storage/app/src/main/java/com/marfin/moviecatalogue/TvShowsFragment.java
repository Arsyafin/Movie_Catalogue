package com.marfin.moviecatalogue;


import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class TvShowsFragment extends Fragment {


    private ArrayList<TvShowsItem> tvShowsItems = new ArrayList<>();
    private TvShowsAdapter tvShowsAdapter;
    private ProgressBar progressBar;
    private TvShowsViewModel tvShowsViewModel;


    public TvShowsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_tvshows, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        final EditText etSearchTvShows = view.findViewById(R.id.et_search_tvshows);
        ImageButton btnSearchTvShows = view.findViewById(R.id.btn_search_tvshows);

        tvShowsViewModel = ViewModelProviders.of(this).get(TvShowsViewModel.class);
        tvShowsViewModel.getTvShows().observe(this, getTvshow);
        tvShowsViewModel.setTvShows(getContext());

        tvShowsAdapter = new TvShowsAdapter(tvShowsItems);
        tvShowsAdapter.notifyDataSetChanged();

        progressBar = view.findViewById(R.id.progress_bar);

        RecyclerView recyclerView = view.findViewById(R.id.rv_tvshows);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(tvShowsAdapter);

        tvShowsAdapter.setOnItemClickCallback(new TvShowsAdapter.OnItemClickCallback() {
            public void onItemClicked(TvShowsItem tvShowsItem) {
                Intent tvShowsDetail = new Intent(getContext(), TvShowsDetail.class);
                tvShowsDetail.putExtra(TvShowsDetail.EXTRA_TVSHOW, tvShowsItem);
                startActivity(tvShowsDetail);
            }
        });

        btnSearchTvShows.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showLoading(true);
                String query = etSearchTvShows.getText().toString();

                if (query.length() > 0) {
                    tvShowsViewModel.searchTvShows(getContext(), query);
                } else {
                    tvShowsViewModel.setTvShows(getContext());
                }
            }
        });
    }

    private void showLoading(Boolean state) {
        if (state) {
            progressBar.setVisibility(View.VISIBLE);
        } else {
            progressBar.setVisibility(View.GONE);
        }
    }

    private Observer<ArrayList<TvShowsItem>> getTvshow = new Observer<ArrayList<TvShowsItem>>() {
        @Override
        public void onChanged(@Nullable ArrayList<TvShowsItem> tvShowsItem) {
            if (tvShowsItem !=null) {
                tvShowsAdapter.setData(tvShowsItem);
                showLoading(false);
            }
        }
    };
}
