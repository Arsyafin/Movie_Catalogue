package com.marfin.moviecatalogue;

import android.content.ContentValues;
import android.net.Uri;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import static com.marfin.moviecatalogue.DatabaseContract.FavoriteMovieColumns.CONTENT_URI;
import static com.marfin.moviecatalogue.DatabaseContract.FavoriteMovieColumns.OVERVIEW;
import static com.marfin.moviecatalogue.DatabaseContract.FavoriteMovieColumns.POSTER_PATH;
import static com.marfin.moviecatalogue.DatabaseContract.FavoriteMovieColumns.TITLE;
import static com.marfin.moviecatalogue.DatabaseContract.FavoriteMovieColumns._ID;
import static com.marfin.moviecatalogue.MainActivity.moviesFavoriteDb;


public class MoviesDetail extends AppCompatActivity {
    public static final String EXTRA_MOVIE = "extra_movie";
    private int id;
    private String title, overview, poster;
    private ImageView ivPoster;
    private TextView tvTitle, tvOverview;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.title_movies);
        setContentView(R.layout.detail_movies);

        bindView();
        getData();
        setData();
    }

    private void bindView() {
        tvTitle = findViewById(R.id.tv_title);
        tvOverview = findViewById(R.id.tv_overview);
        ivPoster = findViewById(R.id.iv_poster);
    }

    private void getData() {
        MoviesItem moviesItem = getIntent().getParcelableExtra(EXTRA_MOVIE);
        id = moviesItem.getId();
        title = moviesItem.getTitle();
        overview = moviesItem.getOverview();
        poster = moviesItem.getPosterpath();
    }

    private void setData() {
        Glide.with(this)
                .load("https://image.tmdb.org/t/p/w185" + poster)
                .into(ivPoster);
        tvTitle.setText(title);
        tvOverview.setText(overview);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        MoviesFavorite movieFav = new MoviesFavorite();
        movieFav.setId(id);
        movieFav.setTitle(title);
        movieFav.setOverview(overview);
        movieFav.setPosterpath(poster);


        ContentValues values = new ContentValues();
        values.put(_ID, id);
        values.put(TITLE, title);
        values.put(OVERVIEW, overview);
        values.put(POSTER_PATH, poster);

        if (item.getItemId() == R.id.favorite) {
            if (item.isChecked()) {
                item.setChecked(false);
                moviesFavoriteDb.moviesFavoriteDao().delete(movieFav);
                FavoritesWidgetProvider.updateWidget(this);
                item.setIcon(R.drawable.ic_border_favorites);
                Toast.makeText(this, R.string.removed_from_favorite, Toast.LENGTH_SHORT).show();
            } else {
                item.setChecked(true);
                moviesFavoriteDb.moviesFavoriteDao().addData(movieFav);
                FavoritesWidgetProvider.updateWidget(this);
                item.setIcon(R.drawable.ic_fill_favorites);
                Toast.makeText(this, R.string.added_to_favorite, Toast.LENGTH_SHORT).show();
            }
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.favorite, menu);

        if (moviesFavoriteDb.moviesFavoriteDao().isFavorite(id) == 1) {
            menu.getItem(0).setIcon(ContextCompat.getDrawable(this,R.drawable.ic_fill_favorites));
            menu.getItem(0).setChecked(true);
        } else {
            menu.getItem(0).setIcon(ContextCompat.getDrawable(this,R.drawable.ic_border_favorites));
            menu.getItem(0).setChecked(false);
        }
        return super.onCreateOptionsMenu(menu);
    }
}
