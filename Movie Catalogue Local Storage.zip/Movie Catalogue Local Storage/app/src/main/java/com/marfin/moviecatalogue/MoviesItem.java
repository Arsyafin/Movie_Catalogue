package com.marfin.moviecatalogue;

import android.os.Parcel;
import android.os.Parcelable;
import org.json.JSONObject;


public class MoviesItem implements Parcelable {

    private int id;
    private String title;
    private String overview;
    private String posterpath;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getPosterpath() {
        return posterpath;
    }

    public void setPosterpath(String posterpath) {
        this.posterpath = posterpath;
    }

    @Override
    public int describeContents() {
        return 0;
    }
    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(id);
        parcel.writeString(this.title);
        parcel.writeString(this.overview);
        parcel.writeString(this.posterpath);
    }

    private MoviesItem(Parcel in) {
        id = in.readInt();
        title = in.readString();
        overview = in.readString();
        posterpath = in.readString();
    }
    public static final Creator<MoviesItem> CREATOR = new Creator<MoviesItem>() {
        @Override
        public MoviesItem createFromParcel(Parcel in) {
            return new MoviesItem(in);
        }
        @Override
        public MoviesItem[] newArray(int size) {
            return new MoviesItem[size];
        }
    };

    MoviesItem(JSONObject object) {
        try {
            int id = object.getInt("id");
            String title = object.getString("title");
            String overview = object.getString("overview");
            String posterpath = object.getString("poster_path");

            this.id = id;
            this.title = title;
            this.overview = overview;
            this.posterpath = posterpath;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
