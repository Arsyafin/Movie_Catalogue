package com.marfin.moviecatalogue;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface TvShowsFavoriteDao {
    @Insert
    public void addData(TvShowsFavorite tvShowFavorite);

    @Query("SELECT * FROM tv_shows_favorite")
    public List<TvShowsFavorite> getFavoriteData();

    @Query("SELECT EXISTS (SELECT 1 FROM tv_shows_favorite WHERE id=:id)")
    public int isFavorite(int id);

    @Delete
    public void delete(TvShowsFavorite tvShowFavorite);
}
