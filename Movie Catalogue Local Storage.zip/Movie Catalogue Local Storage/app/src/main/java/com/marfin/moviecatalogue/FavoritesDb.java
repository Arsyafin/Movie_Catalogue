package com.marfin.moviecatalogue;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {MoviesFavorite.class, TvShowsFavorite.class}, version = 1)

public abstract class FavoritesDb extends RoomDatabase {
    public abstract MoviesFavoriteDao moviesFavoriteDao();
    public abstract TvShowsFavoriteDao tvShowsFavoriteDao();
}
