package com.marfin.moviecatalogue;

import java.util.ArrayList;

public interface LoadFavoriteMovieCallback {
    void preExeccute();

    void postExecute(ArrayList<FavoritesMovie> favoritesMovies);
}
