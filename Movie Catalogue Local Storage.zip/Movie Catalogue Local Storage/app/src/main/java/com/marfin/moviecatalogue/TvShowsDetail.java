package com.marfin.moviecatalogue;

import android.os.Bundle;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import static com.marfin.moviecatalogue.MainActivity.tvShowsFavoriteDb;


public class TvShowsDetail extends AppCompatActivity {
    public static final String EXTRA_TVSHOW = "extra_tvshow";
    private int id;
    private String title, overview, poster;
    private ImageView ivPoster;
    private TextView tvTitle, tvOverview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(R.string.title_tvshows);
        setContentView(R.layout.detail_tvshows);

        bindView();
        getData();
        setData();
    }

    private void bindView() {
        tvTitle = findViewById(R.id.tv_title);
        tvOverview = findViewById(R.id.tv_overview);
        ivPoster = findViewById(R.id.iv_poster);
    }

    private void getData() {
        TvShowsItem tvShowsItem = getIntent().getParcelableExtra(EXTRA_TVSHOW);
        id = tvShowsItem.getId();
        title = tvShowsItem.getTitle();
        overview = tvShowsItem.getOverview();
        poster = tvShowsItem.getPosterpath();
    }

    private void setData() {
        Glide.with(this)
                .load("https://image.tmdb.org/t/p/w342" + poster)
                .into(ivPoster);
        tvTitle.setText(title);
        tvOverview.setText(overview);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        TvShowsFavorite tvShowFav = new TvShowsFavorite();
        tvShowFav.setId(id);
        tvShowFav.setTitle(title);
        tvShowFav.setOverview(overview);
        tvShowFav.setPosterpath(poster);

        if (item.getItemId() == R.id.favorite) {
            if (item.isChecked()) {
                item.setChecked(false);
                tvShowsFavoriteDb.tvShowsFavoriteDao().delete(tvShowFav);
                item.setIcon(R.drawable.ic_border_favorites);
                Toast.makeText(this, R.string.removed_from_favorite, Toast.LENGTH_SHORT).show();
            } else {
                item.setChecked(true);
                tvShowsFavoriteDb.tvShowsFavoriteDao().addData(tvShowFav);
                item.setIcon(R.drawable.ic_fill_favorites);
                Toast.makeText(this, R.string.added_to_favorite, Toast.LENGTH_SHORT).show();
            }
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.favorite, menu);

        if (tvShowsFavoriteDb.tvShowsFavoriteDao().isFavorite(id) == 1) {
            menu.getItem(0).setIcon(ContextCompat.getDrawable(this,R.drawable.ic_fill_favorites));
            menu.getItem(0).setChecked(true);
        } else {
            menu.getItem(0).setIcon(ContextCompat.getDrawable(this,R.drawable.ic_border_favorites));
            menu.getItem(0).setChecked(false);
        }
        return super.onCreateOptionsMenu(menu);
    }
}
