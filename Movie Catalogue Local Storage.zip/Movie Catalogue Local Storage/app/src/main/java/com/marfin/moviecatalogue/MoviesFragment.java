package com.marfin.moviecatalogue;


import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class MoviesFragment extends Fragment {

    private ArrayList<MoviesItem> movieList = new ArrayList<>();
    private MoviesAdapter moviesAdapter;
    private ProgressBar progressBar;
    private MoviesViewModel moviesViewModel;

    public MoviesFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_movies, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        final EditText etSearchMovies = view.findViewById(R.id.et_search_movies);
        ImageButton btnSearchMovies = view.findViewById(R.id.btn_search_movies);

        moviesViewModel = ViewModelProviders.of(this).get(MoviesViewModel.class);
        moviesViewModel.getMovies().observe(this, getMovie);
        moviesViewModel.setMovies(getContext());

        moviesAdapter = new MoviesAdapter(movieList);
        moviesAdapter.notifyDataSetChanged();

        progressBar = view.findViewById(R.id.progress_bar);

        RecyclerView recyclerView = view.findViewById(R.id.rv_movies);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(moviesAdapter);

        moviesAdapter.setOnItemClickCallback(new MoviesAdapter.OnItemClickCallback() {
            public void onItemClicked(MoviesItem moviesItem) {
                Intent moviesDetail = new Intent(getContext(), MoviesDetail.class);
                moviesDetail.putExtra(MoviesDetail.EXTRA_MOVIE, moviesItem);
                startActivity(moviesDetail);
            }
        });

        btnSearchMovies.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showLoading(true);
                String query = etSearchMovies.getText().toString();

                if (query.length() > 0) {
                    moviesViewModel.searchMovies(getContext(), query);
                } else {
                    moviesViewModel.setMovies(getContext());
                }
            }
        });
    }

    private void showLoading(Boolean state) {
        if (state) {
            progressBar.setVisibility(View.VISIBLE);
        } else {
            progressBar.setVisibility(View.GONE);
        }
    }

    private Observer<ArrayList<MoviesItem>> getMovie = new Observer<ArrayList<MoviesItem>>() {
        @Override
        public void onChanged(ArrayList<MoviesItem> moviesItem) {
            showLoading(true);

            if (moviesItem != null) {
                moviesAdapter.setData(moviesItem);
                showLoading(false);
            }
        }
    };
}
