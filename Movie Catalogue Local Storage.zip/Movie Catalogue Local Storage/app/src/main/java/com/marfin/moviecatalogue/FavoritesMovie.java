package com.marfin.moviecatalogue;

import android.database.Cursor;
import android.os.Parcel;
import android.os.Parcelable;

import static android.provider.BaseColumns._ID;
import static com.marfin.moviecatalogue.DatabaseContract.getColumnInt;
import static com.marfin.moviecatalogue.DatabaseContract.getColumnString;

public class FavoritesMovie implements Parcelable {
    private int id;
    private String title;
    private String overview;
    private String posterpath;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getPosterpath() {
        return posterpath;
    }

    public void setPosterpath(String posterpath) {
        this.posterpath = posterpath;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int i) {
        dest.writeInt(this.id);
        dest.writeString(this.title);
        dest.writeString(this.overview);
        dest.writeString(this.posterpath);
    }

    public FavoritesMovie () {

    }

    public FavoritesMovie(int id, String title, String overview, String posterpath) {
        this.id = id;
        this.title = title;
        this.overview = overview;
        this.posterpath = posterpath;
    }

    public FavoritesMovie(Cursor cursor) {
        this.id = getColumnInt(cursor, _ID);
        this.title = getColumnString(cursor, DatabaseContract.FavoriteMovieColumns.TITLE);
        this.overview = getColumnString(cursor, DatabaseContract.FavoriteMovieColumns.OVERVIEW);
        this.posterpath = getColumnString(cursor, DatabaseContract.FavoriteMovieColumns.POSTER_PATH);
    }

    private FavoritesMovie(Parcel in) {
        this.id = in.readInt();
        this.title = in.readString();
        this.overview = in.readString();
        this.posterpath = in.readString();
    }

    public static final Parcelable.Creator<FavoritesMovie> CREATOR = new Parcelable.Creator<FavoritesMovie>() {
        @Override
        public FavoritesMovie createFromParcel(Parcel source) {
            return new FavoritesMovie(source);
        }

        @Override
        public FavoritesMovie[] newArray(int size) {
            return new FavoritesMovie[size];
        }
    };
}
