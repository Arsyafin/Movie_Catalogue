package com.marfin.moviecatalogue;

import android.database.Cursor;
import android.os.Parcel;
import android.os.Parcelable;

import static android.provider.BaseColumns._ID;
import static com.marfin.moviecatalogue.DatabaseContract.getColumnInt;
import static com.marfin.moviecatalogue.DatabaseContract.getColumnString;

public class FavoritesMovieItem implements Parcelable {
    private int id;
    private String title;
    private String overview;
    private String posterpath;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getPosterPath() {
        return posterpath;
    }

    public void setPosterPath(String posterPath) {
        this.posterpath = posterPath;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.id);
        dest.writeString(this.title);
        dest.writeString(this.overview);
        dest.writeString(this.posterpath);
    }

    public FavoritesMovieItem(int id, String title, String overview, String posterpath) {
        this.id = id;
        this.title = title;
        this.overview = overview;
        this.posterpath = posterpath;
    }

    public FavoritesMovieItem(Cursor cursor) {
        this.id = getColumnInt(cursor, _ID);
        this.title = getColumnString(cursor, DatabaseContract.FavoriteMovieColumns.TITLE);
        this.overview = getColumnString(cursor, DatabaseContract.FavoriteMovieColumns.OVERVIEW);
        this.posterpath = getColumnString(cursor, DatabaseContract.FavoriteMovieColumns.POSTER_PATH);
    }

    private FavoritesMovieItem(Parcel in) {
        this.id = in.readInt();
        this.title = in.readString();
        this.overview = in.readString();
        this.posterpath = in.readString();
    }

    public static final Creator<FavoritesMovieItem> CREATOR = new Creator<FavoritesMovieItem>() {
        @Override
        public FavoritesMovieItem createFromParcel(Parcel source) {
            return new FavoritesMovieItem(source);
        }

        @Override
        public FavoritesMovieItem[] newArray(int size) {
            return new FavoritesMovieItem[size];
        }
    };
}