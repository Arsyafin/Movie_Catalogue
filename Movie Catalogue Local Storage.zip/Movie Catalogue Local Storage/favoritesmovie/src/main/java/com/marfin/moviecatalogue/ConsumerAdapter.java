package com.marfin.moviecatalogue;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class ConsumerAdapter extends RecyclerView.Adapter<ConsumerAdapter.FavoriteMovieViewHolder> {

    private final ArrayList<FavoritesMovieItem> listFavoriteMovie = new ArrayList<>();
    private final Activity activity;

    public ConsumerAdapter(Activity activity) {
        this.activity = activity;
    }

    public ArrayList<FavoritesMovieItem> getListFavoriteMovie() {
        return listFavoriteMovie;
    }

    public void setListFavoriteMovie(ArrayList<FavoritesMovieItem> listFavoriteMovie) {
        this.listFavoriteMovie.clear();
        this.listFavoriteMovie.addAll(listFavoriteMovie);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public FavoriteMovieViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row_favorites, parent, false);
        return new FavoriteMovieViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FavoriteMovieViewHolder holder, int i) {
        holder.tvTitle.setText(getListFavoriteMovie().get(i).getTitle());
        holder.tvOverview.setText(getListFavoriteMovie().get(i).getOverview());
        Glide.with(holder.itemView.getContext())
                .load("https://image.tmdb.org/t/p/w185" + getListFavoriteMovie().get(i).getPosterPath())
                .apply(new RequestOptions().override(350, 550))
                .into(holder.ivPoster);
    }

    @Override
    public int getItemCount() {
        return listFavoriteMovie.size();
    }

    public class FavoriteMovieViewHolder extends RecyclerView.ViewHolder {
        final TextView tvTitle, tvOverview;
        ImageView ivPoster;

        public FavoriteMovieViewHolder(View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvOverview = itemView.findViewById(R.id.tv_overview);
            ivPoster = itemView.findViewById(R.id.iv_poster);
        }
    }
}
