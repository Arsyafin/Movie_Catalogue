package com.marfin.moviecatalogue;

import android.database.Cursor;

import java.util.ArrayList;

import static android.provider.BaseColumns._ID;
import static com.marfin.moviecatalogue.DatabaseContract.FavoriteMovieColumns.TITLE;
import static com.marfin.moviecatalogue.DatabaseContract.FavoriteMovieColumns.OVERVIEW;
import static com.marfin.moviecatalogue.DatabaseContract.FavoriteMovieColumns.POSTER_PATH;


public class MappingHelper {

    public static ArrayList<FavoritesMovieItem> mapCursorToArrayList(Cursor notesCursor) {
        ArrayList<FavoritesMovieItem> favoriteMovieList = new ArrayList<>();
        while (notesCursor.moveToNext()) {
            int id = notesCursor.getInt(notesCursor.getColumnIndexOrThrow(_ID));
            String title = notesCursor.getString(notesCursor.getColumnIndexOrThrow(TITLE));
            String overview = notesCursor.getString(notesCursor.getColumnIndexOrThrow(OVERVIEW));
            String posterpath = notesCursor.getString(notesCursor.getColumnIndexOrThrow(POSTER_PATH));
            favoriteMovieList.add(new FavoritesMovieItem(id, title, overview, posterpath));
        }
        return favoriteMovieList;
    }
}
