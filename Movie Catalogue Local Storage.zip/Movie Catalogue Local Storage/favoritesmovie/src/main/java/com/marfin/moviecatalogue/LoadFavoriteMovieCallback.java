package com.marfin.moviecatalogue;

import android.database.Cursor;

interface LoadFavoriteMovieCallback {
    void postExecute(Cursor notes);
}
